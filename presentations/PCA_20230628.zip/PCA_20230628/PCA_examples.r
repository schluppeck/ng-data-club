library(dplyr)
library(tidyverse)
library(tibble)

wine_data = read.csv('input/PCA_EXAMPLE/WINE.csv', row=1)
wine_data

pca_model = prcomp(wine_data, scale = TRUE)

# eigenvalues are the variances of PCs
eigenvalues = (pca_model$sdev)^2
pc_names = colnames(pca_model$x)
df_scree = data.frame(pc_names, eigenvalues)
ggplot(data = df_scree, aes(x=pc_names, y=eigenvalues)) + geom_bar(stat="identity")


# loading matrix Q (squared elements of each PC sum to 1), this is different from the correlations between variable and PC
loading_Q = pca_model$rotation
loading_Q

# loading - the correlations between variable and PC
# PC_scores = pca_model$x      # same as: scale(wine_data) %*% loading_Q[,1:2]
# df_temp = cbind(PC_scores, wine_data)
# loading_correlation = cor(df_temp)[rownames(loading_Q), colnames(loading_Q)]
# loading_correlation

colSums(loading_Q ^ 2)
rowSums(loading_Q ^ 2)

# before rotation
library(ggforce)
corr_circle = as.data.frame(loading_Q) %>% tibble::rownames_to_column('features') %>% select(features, PC1, PC2)
# corr_circle
p1 = ggplot(data = corr_circle, aes(x = PC1, y=PC2, label=features)) + 
        geom_point() + geom_text(hjust=0, vjust=0) + xlim(-1, 1) + ylim(-1,1) +
        geom_circle(aes(x0 =0, y0 = 0, r = 1)) 
p1

# after rotation
varimax_Q <- varimax(loading_Q[,1:2])
loading_Q_varimax = loading_Q[,1:2] %*% varimax_Q$rotmat
colnames(loading_Q_varimax) = c('PC1', 'PC2')
loading_Q_varimax = as.data.frame(loading_Q_varimax) %>% tibble::rownames_to_column('features')

p2 = ggplot(data = loading_Q_varimax, aes(x = PC1, y=PC2, label=features)) + 
        geom_point() + geom_text(hjust=0, vjust=0) + xlim(-1, 1) + ylim(-1,1) +
        geom_circle(aes(x0 =0, y0 = 0, r = 1)) 
p2


print('before rotation')
loading_Q[,1:2]
print('after rotation')
loading_Q_varimax

# # after rotation
# varimax_Q <- varimax(loading_Q[,1:2])
# loading_Q_varimax = loading_Q[,1:2] %*% varimax_Q$rotmat

# colnames(loading_Q_varimax) = c('PC1', 'PC2')
# new_PC_score = scale(wine_data) %*% loading_Q_varimax
# df_temp = cbind(new_PC_score, wine_data)
# new_loading_correlation = cor(df_temp)[rownames(loading_Q_varimax), colnames(loading_Q_varimax)]
# new_loading_correlation

# library(ggforce)
# corr_circle = as.data.frame(new_loading_correlation) %>% tibble::rownames_to_column('features') %>% select(features, PC1, PC2)
# p2 = ggplot(data = corr_circle, aes(x = PC1, y=PC2, label=features)) + 
#         geom_point() + geom_text(hjust=0, vjust=0) + xlim(-1, 1) + ylim(-1,1) +
#         geom_circle(aes(x0 =0, y0 = 0, r = 1)) 
# p2

food_data = read.csv('input/PCA_EXAMPLE/Francs.csv', row=1)
food_data
pca_model = prcomp(food_data, center = TRUE, scale. = FALSE)

# eigenvalues are the variances of PCs
eigenvalues = (pca_model$sdev)^2
variance_explained = eigenvalues/ sum(eigenvalues)
pc_names = colnames(pca_model$x)
df_scree = data.frame(pc_names, variance_explained)
ggplot(data = df_scree, aes(x=pc_names, y=variance_explained)) + geom_bar(stat="identity")


# loading matrix Q (squared elements of each PC sum to 1), this is different from the correlations between variable and PC
loading_Q = pca_model$rotation
# loading_Q

# loading - the correlations between variable and PC
PC_scores = pca_model$x      # same as: scale(wine_data) %*% loading_Q[,1:2]
df_temp = cbind(PC_scores, food_data)
loading_correlation = cor(df_temp)[rownames(loading_Q), colnames(loading_Q)]
# loading_correlation


rowSums(loading_Q ^ 2)
colSums(loading_Q ^ 2)
# rowSums(loading_correlation ^ 2)

df_cases = as.data.frame(PC_scores[,1:2]) %>% 
            tibble::rownames_to_column('individuals') %>% 
            mutate(class = str_sub(individuals,1,2))
df_cases$class = factor(df_cases$class)
p1 = ggplot(data = df_cases, aes(x = PC1, y=PC2, label=individuals, color = class)) + 
        geom_point() + geom_text(hjust=0, vjust=0) + xlim(-1000, 1000) + ylim(-1000,1000)

p1

# # before rotation
# library(ggforce)
# corr_circle = as.data.frame(loading_Q) %>% tibble::rownames_to_column('features') %>% select(features, PC1, PC2)
# corr_circle
# p1 = ggplot(data = corr_circle, aes(x = PC1, y=PC2, label=features)) + 
#         geom_point() + geom_text(nudge_x =-0.1,nudge_y =0.1) + xlim(-1, 1) + ylim(-1,1) +
#         geom_circle(aes(x0 =0, y0 = 0, r = 1)) 
# p1

# df_biplot = rbind(as.data.frame(loading_correlation)[1:2], as.data.frame(PC_scores[,1:2]))
# df_biplot$label = rep(c('variables','cases'), times=c(7,12))
# df_biplot$label = factor(df_biplot$label)
# df_biplot = df_biplot %>% tibble::rownames_to_column('names')

p_bi = biplot(pca_model)
p_bi

# different diagnostic label
who_gambled_2016 = read.csv('output/who_gambled_2016.csv', row =1)
who_gambled_2016 = who_gambled_2016$subjectkey 
print(paste('who_gambled_2016:',length(who_gambled_2016)))

label = read.csv('output/year2016_gambler_PPGM_Label.csv', row =1) %>% select(subjectkey, diagnosis_ppgm)

data_2016 = read.csv('output/HarmSurvey2016.csv', row =1)

dim(data_2016)

gambler_data_2016 = data_2016 %>% filter(subjectkey %in% who_gambled_2016)
harm_data_temp = gambler_data_2016 %>% dplyr::select(subjectkey,starts_with('h')) 
harm_data_temp = merge(harm_data_temp, label, by = 'subjectkey')

harm_data = harm_data_temp %>% tibble::column_to_rownames(var = 'subjectkey')
dim(harm_data)
head(harm_data,2)

df=harm_data%>% select(starts_with('hf'),diagnosis_ppgm)
table = sapply(df[ ,1:ncol(df)-1], function(x) tapply(x, df[ ,ncol(df)], sum))
table  
table_centered = scale( table, center = TRUE, scale = FALSE)           
# table_normalized = table
# for (i in 1:ncol(table)){
#     table_normalized[,i] = table[,i] / colSums(table)[[i]] 
#     table_normalized = scale( table_normalized, center = TRUE, scale = FALSE)
#     }
# table_normalized
res.ca <- CA(table, graph = TRUE) 

# book_data = read.csv('input/PCA_EXAMPLE/punctuation.csv', row=1)
# book_data

# library("FactoMineR")
# library("factoextra")

# # Graph of contingency tables
# library("gplots")
# # 1. convert the data as a table
# dt <- as.table(as.matrix(book_data))
# # 2. Graph
# balloonplot(t(dt), main ="book_data", xlab ="", ylab="",label = FALSE, show.margins = FALSE)


# # the projection of rows and columns
# res.ca <- CA(book_data, graph = TRUE)
# # print(res.ca)

wineRate_data_RAW = read.csv('input/PCA_EXAMPLE/mfa_wine.csv', row=1) %>% select(-oak_type)
wineRate_data_RAW

wineRate_data = wineRate_data_RAW
pca_model_1 = prcomp(wineRate_data[1:3], center = TRUE, scale. = TRUE)
SV_1 = pca_model_1$sdev
pca_model_2 = prcomp(wineRate_data[4:7], center = TRUE, scale. = TRUE)
SV_2 = pca_model_2$sdev
pca_model_3 = prcomp(wineRate_data[8:10], center = TRUE, scale. = TRUE)
SV_3 = pca_model_3$sdev
SV_1[1]
SV_2[1]
SV_3[1]

# standardization + normalization
wineRate_data[1:3] = scale(wineRate_data[1:3])/SV_1[1]
wineRate_data[4:7] = scale(wineRate_data[4:7])/SV_2[1]
wineRate_data[8:10] = scale(wineRate_data[8:10])/SV_3[1]
wineRate_data

wineRate_data$oak_type = c('oak_1','oak_2','oak_2','oak_2','oak_1','oak_1')
wineRate_data$oak_type = factor(wineRate_data$oak_type)

library(FactoMineR)
res.mfa <- MFA(wineRate_data, 
               group = c( 3, 4, 3,1), 
               type = c("s", "s", "s", "n"),
               name.group = c("expert1", "expert2", "expert3",'oak_type'),
               num.group.sup = 4,
               graph = F)


get_eigenvalue(res.mfa)

fviz_screeplot(res.mfa)


fviz_mfa_ind(res.mfa, col.ind = "cos2", 
             gradient.cols = c("#00AFBB", "#E7B800", "#FC4E07"),
             repel = TRUE)

fviz_mfa_ind(res.mfa, 
             habillage = "oak_type", # color by groups 
             palette = c("#00AFBB", "#E7B800", "#FC4E07"),
             addEllipses = TRUE, ellipse.type = "confidence", 
             repel = TRUE # Avoid text overlapping
             ) 

fviz_mfa_var(res.mfa, "group")

# fviz_mfa_var(res.mfa, "quanti.var", palette = "jco", 
#              col.var.sup = "violet", repel = TRUE)

fviz_mfa_var(res.mfa, "quanti.var", palette = "jco", 
             col.var.sup = "violet", repel = TRUE,
             geom = c("point", "text"), legend = "top")


